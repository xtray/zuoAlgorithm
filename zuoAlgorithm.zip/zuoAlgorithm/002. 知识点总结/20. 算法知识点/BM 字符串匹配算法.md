# BM 字符串匹配算法
Boyer-Moore string search algorithm

不要求掌握

---

>是由两位发明者 Boyer 和 Moore 的名字命名的，其核心思想是在主串和模式串进行比较时，如果出现了不匹配的情况，能够尽可能多的获取一些信息，借此跳过那些肯定不会匹配的情况，以此来提升字符串匹配的效率，大多数文本编辑器中的字符查找功能，一般都会使用 BM 算法来实现。


https://www.jianshu.com/p/2118dc00d022/